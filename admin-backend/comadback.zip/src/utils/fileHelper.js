const fs = require("fs");
const path = require("path");


// Agar imageUrl hamare apne /uploads/ folder ki file hai, to usay disk se delete kar do
// (agar koi bahar ka URL hai, to usay chhed nahi karte)
function deleteUploadedFile(imageUrl) {

  if (!imageUrl || !imageUrl.includes("/uploads/")) {
    return;
  }

  const filename = imageUrl.split("/uploads/")[1];

  if (!filename) {
    return;
  }

  const filePath = path.join(__dirname, "../../uploads", filename);

  fs.unlink(filePath, (err) => {
    if (err) {
      console.log("Old image delete nahi ho saki (shayad pehle se nahi thi):", err.message);
    }
  });

}


module.exports = { deleteUploadedFile };
